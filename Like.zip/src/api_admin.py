"""
API Key Administration Tool
CLI tool to manage API keys - create, list, activate, deactivate, reset
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.api_key_manager import key_manager
import json


def print_header(title: str):
    """Print formatted header"""
    print("\n" + "=" * 70)
    print(f"        {title}")
    print("=" * 70 + "\n")


def create_key():
    """Create a new API key"""
    print_header("🔑 Create New API Key")
    
    name = input("Enter key name (e.g., 'Production', 'Development'): ").strip()
    if not name:
        name = "Unnamed Key"
    
    api_key = key_manager.generate_api_key(name)
    
    print(f"\n✅ API Key Created Successfully!")
    print(f"\n🔑 API Key: {api_key}")
    print(f"📝 Name: {name}")
    print(f"\n⚠️  IMPORTANT: Save this key securely. You won't be able to see it again!")
    print(f"\n💡 This key will be locked to the IP address on first use.")


def list_keys():
    """List all API keys"""
    print_header("📋 All API Keys")
    
    keys = key_manager.list_all_keys()
    
    if not keys:
        print("❌ No API keys found.")
        return
    
    for masked_key, info in keys.items():
        status = "🟢 Active" if info["is_active"] else "🔴 Inactive"
        lock_status = "🔒 Locked" if info["is_locked"] else "🔓 Unlocked"
        
        print(f"\nKey: {masked_key}")
        print(f"  Name: {info['name']}")
        print(f"  Status: {status}")
        print(f"  Lock: {lock_status}")
        print(f"  Created: {info['created_at']}")
        print(f"  Usage: {info['usage_count']} times")
        print(f"  Last Used: {info['last_used']}")


def deactivate_key():
    """Deactivate an API key"""
    print_header("🔴 Deactivate API Key")
    
    api_key = input("Enter full API key to deactivate: ").strip()
    
    if key_manager.deactivate_key(api_key):
        print(f"\n✅ API key deactivated successfully!")
    else:
        print(f"\n❌ API key not found!")


def activate_key():
    """Activate an API key"""
    print_header("🟢 Activate API Key")
    
    api_key = input("Enter full API key to activate: ").strip()
    
    if key_manager.activate_key(api_key):
        print(f"\n✅ API key activated successfully!")
    else:
        print(f"\n❌ API key not found!")


def reset_lock():
    """Reset location lock for an API key"""
    print_header("🔓 Reset Location Lock")
    
    api_key = input("Enter full API key to reset lock: ").strip()
    
    print(f"\n⚠️  WARNING: This will allow the key to be used from a new location.")
    confirm = input("Are you sure? (yes/no): ").strip().lower()
    
    if confirm == "yes":
        if key_manager.reset_key_lock(api_key):
            print(f"\n✅ Location lock reset successfully!")
            print(f"💡 The key will lock to the next IP address that uses it.")
        else:
            print(f"\n❌ API key not found!")
    else:
        print(f"\n❌ Operation cancelled.")


def delete_key():
    """Delete an API key permanently"""
    print_header("🗑️  Delete API Key")
    
    api_key = input("Enter full API key to delete: ").strip()
    
    print(f"\n⚠️  WARNING: This action cannot be undone!")
    confirm = input("Are you sure? (yes/no): ").strip().lower()
    
    if confirm == "yes":
        if key_manager.delete_key(api_key):
            print(f"\n✅ API key deleted successfully!")
        else:
            print(f"\n❌ API key not found!")
    else:
        print(f"\n❌ Operation cancelled.")


def show_key_info():
    """Show detailed information about an API key"""
    print_header("ℹ️  API Key Information")
    
    api_key = input("Enter full API key: ").strip()
    
    info = key_manager.get_key_info(api_key)
    
    if info:
        print(f"\n📊 Key Details:")
        print(json.dumps(info, indent=2))
    else:
        print(f"\n❌ API key not found!")


def main():
    """Main menu"""
    print_header("🔐 FreeFire API Key Administration")
    
    while True:
        print("\nOptions:")
        print("  1. Create new API key")
        print("  2. List all API keys")
        print("  3. Show key info")
        print("  4. Activate API key")
        print("  5. Deactivate API key")
        print("  6. Reset location lock")
        print("  7. Delete API key")
        print("  8. Exit")
        
        choice = input("\nSelect option (1-8): ").strip()
        
        if choice == "1":
            create_key()
        elif choice == "2":
            list_keys()
        elif choice == "3":
            show_key_info()
        elif choice == "4":
            activate_key()
        elif choice == "5":
            deactivate_key()
        elif choice == "6":
            reset_lock()
        elif choice == "7":
            delete_key()
        elif choice == "8":
            print("\n👋 Goodbye!\n")
            break
        else:
            print("\n❌ Invalid option!")


if __name__ == "__main__":
    main()
