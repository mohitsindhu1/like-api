"""
FreeFire Like API Server
API endpoint to send likes with authentication
"""

import asyncio
import random
from typing import Optional, List, Dict, Any
from datetime import datetime

from fastapi import FastAPI, HTTPException, Header, Depends, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from src.api_config import MAX_LIKES_PER_REQUEST, ADMIN_PASSWORD
from src.api_key_manager import key_manager
from src.profile_fetcher import get_profile_info
from send_like_fixed import (
    load_region_guests,
    ensure_target,
    guest_used_for_target,
    like_with_guest,
    save_usage,
    get_base_url
)
from count_likes import GetAccountInformation, SUPPORTED_REGIONS

app = FastAPI(
    title="FreeFire Like API",
    description="API for sending automated likes to FreeFire profiles",
    version="1.0.0"
)


class LikeRequest(BaseModel):
    uid: int = Field(..., description="Target UID to send likes to")
    region: str = Field(..., description="Server region (IND, BD, BR, US, SG)")
    count: Optional[int] = Field(101, description="Number of likes to send (max 101)")


class LikeResponse(BaseModel):
    success: bool
    message: str
    profile: Optional[Dict[str, Any]] = None
    results: Optional[Dict[str, Any]] = None


def verify_api_key(
    request: Request,
    x_api_key: Optional[str] = Header(None)
):
    """Verify API key with IP-based location locking"""
    if not x_api_key:
        raise HTTPException(
            status_code=401,
            detail="API key missing. Please provide X-API-Key header."
        )
    
    # Get client IP and user agent
    client_ip = request.client.host if request.client else "unknown"
    user_agent = request.headers.get("user-agent", "unknown")
    
    # Validate key with location locking
    is_valid, error_msg = key_manager.validate_key(x_api_key, client_ip, user_agent)
    
    if not is_valid:
        raise HTTPException(
            status_code=403,
            detail=error_msg
        )
    
    return x_api_key


@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "service": "FreeFire Like API",
        "status": "running",
        "version": "1.0.0",
        "endpoints": {
            "simple_like": "/like?uid=&server=&api= (GET) - Simple endpoint",
            "send_likes": "/api/send-likes (POST) - Advanced endpoint",
            "get_info": "/info?uid=&api= (GET) - Get user info across all regions",
            "check_uid": "/check-uid?uid=&api= (GET) - Check UID across all regions",
            "health": "/health (GET)"
        },
        "examples": {
            "send_like": "/like?uid=123456&server=IND&api=your_key&count=50",
            "get_info": "/info?uid=2926998273&api=your_key",
            "check_uid": "/check-uid?uid=123456&api=your_key"
        }
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}


@app.get("/like")
async def simple_like(
    request: Request,
    uid: int,
    server: str,
    api: str,
    count: Optional[int] = 101
):
    """
    Simple GET endpoint to send likes
    
    Query Parameters:
    - uid: Target UID
    - server: Region (IND, BD, BR, US, SG)
    - api: Your API key
    - count: Number of likes (optional, default 101)
    
    Example: /like?uid=123456&server=IND&api=your_key&count=50
    """
    
    # Validate API key
    client_ip = request.client.host if request and request.client else "unknown"
    user_agent = request.headers.get("user-agent", "unknown") if request else "unknown"
    
    is_valid, error_msg = key_manager.validate_key(api, client_ip, user_agent)
    if not is_valid:
        return {"success": False, "error": error_msg}
    
    # Validate region
    region = server.upper()
    valid_regions = ["IND", "BD", "BR", "US", "SG"]
    if region not in valid_regions:
        return {"success": False, "error": f"Invalid server. Use: {', '.join(valid_regions)}"}
    
    try:
        # STEP 1: Fetch profile BEFORE sending likes
        print(f"[Simple API] Fetching profile BEFORE sending likes for UID {uid}...")
        profile_before = await get_profile_info(uid, region)
        
        likes_before = 0
        player_name = f'Player_{uid}'
        
        if profile_before and profile_before.get('success'):
            likes_before = profile_before.get('likes', 0)
            player_name = profile_before.get('nickname', f'Player_{uid}')
            print(f"[Simple API] Profile BEFORE: {player_name} | Likes: {likes_before}")
        
        # STEP 2: Load guests
        guests = load_region_guests(region)
        if not guests:
            return {"success": False, "error": f"No accounts available for {region}"}
        
        # Filter unused guests
        target_uid = str(uid)
        ensure_target(target_uid)
        available_guests = [
            g for g in guests 
            if not guest_used_for_target(target_uid, str(g["uid"]))
        ]
        
        if not available_guests:
            return {"success": False, "error": f"No unused {region} accounts for UID {uid}"}
        
        # STEP 3: Select and send likes
        selected_count = min(count or 101, MAX_LIKES_PER_REQUEST, len(available_guests))
        selected_guests = random.sample(available_guests, selected_count)
        
        print(f"[Simple API] Sending {selected_count} likes...")
        
        # Send likes concurrently
        semaphore = asyncio.Semaphore(10)
        tasks = [like_with_guest(guest, target_uid, semaphore) for guest in selected_guests]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Count success
        success_count = sum(1 for r in results if r is True)
        
        # Save usage
        save_usage()
        
        # STEP 4: Fetch profile AFTER sending likes
        print(f"[Simple API] Fetching profile AFTER sending likes for UID {uid}...")
        profile_after = await get_profile_info(uid, region)
        
        likes_after = likes_before  # Default to before if fetch fails
        
        if profile_after and profile_after.get('success'):
            likes_after = profile_after.get('likes', likes_before)
            player_name_after = profile_after.get('nickname', player_name)
            # Use after name if available, otherwise keep before name
            if player_name_after:
                player_name = player_name_after
            print(f"[Simple API] Profile AFTER: {player_name} | Likes: {likes_after}")
        
        # STEP 5: Calculate difference
        likes_sent = likes_after - likes_before
        status = 1 if likes_sent > 0 else 2
        
        print(f"[Simple API] ✅ Likes sent: {likes_sent} (Before: {likes_before} → After: {likes_after})")
        
        # Prepare response with before/after data
        response = {
            "success": True,
            "uid": uid,
            "region": region,
            "profile": {
                "player_nickname": player_name,
                "likes_before": likes_before,
                "likes_after": likes_after,
                "likes_difference": likes_sent
            },
            "results": {
                "requested_likes": selected_count,
                "successful_accounts": success_count,
                "actual_likes_sent": likes_sent,
                "status": status
            },
            "summary": f"✅ {player_name}: {likes_before} → {likes_after} (+{likes_sent} likes) in {region}"
        }
        
        return response
        
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.post("/api/send-likes", response_model=LikeResponse)
async def send_likes(
    req: Request,
    request: LikeRequest,
    api_key: str = Depends(verify_api_key)
):
    """
    Send likes to a target UID from multiple guest accounts
    
    Requires X-API-Key header for authentication
    """
    
    region = request.region.upper()
    target_uid = str(request.uid)
    like_count = min(request.count or 101, MAX_LIKES_PER_REQUEST)
    
    # Validate region
    valid_regions = ["IND", "BD", "BR", "US", "SG"]
    if region not in valid_regions:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid region. Valid regions: {', '.join(valid_regions)}"
        )
    
    try:
        # Step 1: Fetch profile information BEFORE sending likes
        print(f"[API] Fetching profile BEFORE sending likes for UID {target_uid}...")
        profile_before = await get_profile_info(request.uid, region)
        
        likes_before = 0
        player_name = f'Player_{request.uid}'
        
        if profile_before and profile_before.get('success'):
            likes_before = profile_before.get('likes', 0)
            player_name = profile_before.get('nickname', f'Player_{request.uid}')
            print(f"[API] Profile BEFORE: {player_name} | Likes: {likes_before}")
        
        # Step 2: Load region-specific guests
        print(f"[API] Loading {region} guest accounts...")
        guests = load_region_guests(region)
        
        if not guests:
            raise HTTPException(
                status_code=404,
                detail=f"No guest accounts available for region {region}"
            )
        
        # Step 3: Filter unused guests
        ensure_target(target_uid)
        available_guests = [
            g for g in guests 
            if not guest_used_for_target(target_uid, str(g["uid"]))
        ]
        
        if not available_guests:
            raise HTTPException(
                status_code=400,
                detail=f"No unused {region} guests available for UID {target_uid}"
            )
        
        # Step 4: Select random guests (up to requested count)
        selected_count = min(like_count, len(available_guests))
        selected_guests = random.sample(available_guests, selected_count)
        
        print(f"[API] Sending {selected_count} likes from {region} accounts...")
        
        # Step 5: Send likes concurrently
        semaphore = asyncio.Semaphore(10)  # 10 concurrent requests
        
        tasks = []
        for guest in selected_guests:
            tasks.append(like_with_guest(guest, target_uid, semaphore))
        
        # Execute all tasks
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Step 6: Process results
        success_count = sum(1 for r in results if r is True)
        error_count = sum(1 for r in results if isinstance(r, Exception) or r is False)
        
        # Save usage history
        save_usage()
        
        # Step 6.5: Fetch profile AFTER sending likes
        print(f"[API] Fetching profile AFTER sending likes for UID {target_uid}...")
        profile_after = await get_profile_info(request.uid, region)
        
        likes_after = likes_before  # Default to before if fetch fails
        
        if profile_after and profile_after.get('success'):
            likes_after = profile_after.get('likes', likes_before)
            player_name_after = profile_after.get('nickname', player_name)
            if player_name_after:
                player_name = player_name_after
            print(f"[API] Profile AFTER: {player_name} | Likes: {likes_after}")
        
        # Calculate difference
        likes_sent = likes_after - likes_before
        status = 1 if likes_sent > 0 else 2
        
        print(f"[API] ✅ Likes difference: {likes_sent} (Before: {likes_before} → After: {likes_after})")
        
        # Step 7: Prepare response with before/after data
        response_data = {
            "success": success_count > 0,
            "uid": request.uid,
            "region": region,
            "profile": {
                'player_nickname': player_name,
                'likes_before': likes_before,
                'likes_after': likes_after,
                'likes_difference': likes_sent
            },
            "results": {
                "requested_likes": selected_count,
                "successful_accounts": success_count,
                "failed_accounts": error_count,
                "actual_likes_sent": likes_sent,
                "status": status,
                "timestamp": datetime.utcnow().isoformat()
            },
            "summary": f"✅ {player_name}: {likes_before} → {likes_after} (+{likes_sent} likes) in {region}"
        }
        
        print(f"[API] ✅ Completed: {success_count}/{selected_count} likes sent | Difference: {likes_sent}")
        
        return JSONResponse(
            status_code=200,
            content=response_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"[API] ❌ Error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )


@app.get("/api/regions")
async def get_regions(request: Request, api_key: str = Depends(verify_api_key)):
    """Get available regions and account counts"""
    from send_like_fixed import get_available_regions
    
    regions = get_available_regions()
    
    return {
        "regions": regions,
        "total_regions": len(regions)
    }


async def _check_uid_logic(request: Request, uid: int, api: str):
    """
    Shared logic for checking UID across all regions
    """
    # Validate API key
    client_ip = request.client.host if request and request.client else "unknown"
    user_agent = request.headers.get("user-agent", "unknown") if request else "unknown"
    
    is_valid, error_msg = key_manager.validate_key(api, client_ip, user_agent)
    if not is_valid:
        return {"success": False, "error": error_msg}
    
    print(f"\n[Check UID] Checking UID {uid} across all regions...")
    
    # Check across all regions
    results = {}
    endpoint = "/GetPlayerPersonalShow"
    
    tasks = []
    for region in SUPPORTED_REGIONS:
        tasks.append(GetAccountInformation(uid, "0", region, endpoint))
    
    # Execute all region checks concurrently
    region_results = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Process results
    found_in_regions = []
    for region, result in zip(SUPPORTED_REGIONS, region_results):
        if isinstance(result, Exception):
            results[region] = {
                "found": False,
                "error": str(result)
            }
        elif isinstance(result, dict) and result.get("error"):
            results[region] = {
                "found": False,
                "error": result.get("message", "Unknown error")
            }
        elif isinstance(result, dict):
            # Extract profile information
            basic_info = result.get("basicInfo", {})
            player_nickname = basic_info.get("nickname", f"Player_{uid}")
            likes = basic_info.get("liked", 0)
            level = basic_info.get("level", 0)
            
            results[region] = {
                "found": True,
                "player_nickname": player_nickname,
                "likes": likes,
                "level": level,
                "uid": uid
            }
            found_in_regions.append(region)
            
            print(f"  ✅ {region}: {player_nickname} | Likes: {likes} | Level: {level}")
        else:
            results[region] = {
                "found": False,
                "error": "Unknown response format"
            }
    
    # Prepare response
    response = {
        "success": True,
        "uid": uid,
        "found_in_regions": found_in_regions,
        "total_regions_found": len(found_in_regions),
        "regions_data": results
    }
    
    print(f"\n[Check UID] ✅ UID {uid} found in {len(found_in_regions)} regions: {', '.join(found_in_regions)}\n")
    
    return response


@app.get("/info")
async def get_uid_info(
    request: Request,
    uid: int,
    api: str
):
    """
    Get user information by UID - checks across all regions
    
    Query Parameters:
    - uid: Target UID to check
    - api: Your API key
    
    Example: /info?uid=2926998273&api=your_key
    """
    return await _check_uid_logic(request, uid, api)


@app.get("/check-uid")
async def check_uid_across_regions(
    request: Request,
    uid: int,
    api: str
):
    """
    Check a UID across all regions and show complete profile information
    
    Query Parameters:
    - uid: Target UID to check
    - api: Your API key
    
    Example: /check-uid?uid=123456&api=your_key
    """
    return await _check_uid_logic(request, uid, api)


@app.post("/api/admin/create-key")
async def create_api_key(
    request: Request,
    key_name: str = "default",
    admin_password: str = Header(None, alias="X-Admin-Password")
):
    """
    Create a new API key (Admin only)
    Requires X-Admin-Password header (set via FF_ADMIN_PASSWORD env variable)
    """
    if admin_password != ADMIN_PASSWORD:
        raise HTTPException(
            status_code=403,
            detail="Invalid admin password"
        )
    
    new_key = key_manager.generate_api_key(key_name)
    
    return {
        "success": True,
        "api_key": new_key,
        "name": key_name,
        "message": "API key created successfully. Save it securely!",
        "note": "This key will be locked to the IP address on first use."
    }


@app.get("/api/admin/list-keys")
async def list_api_keys(
    request: Request,
    admin_password: str = Header(None, alias="X-Admin-Password")
):
    """
    List all API keys (Admin only)
    Requires X-Admin-Password header (set via FF_ADMIN_PASSWORD env variable)
    """
    if admin_password != ADMIN_PASSWORD:
        raise HTTPException(
            status_code=403,
            detail="Invalid admin password"
        )
    
    return {
        "keys": key_manager.list_all_keys()
    }


if __name__ == "__main__":
    import uvicorn
    
    print("=" * 70)
    print("        🚀 FreeFire Like API Server")
    print("=" * 70)
    print(f"\n🔐 Multi-API Key System: Enabled")
    print(f"📍 Server: http://0.0.0.0:5000")
    print(f"📚 Docs: http://0.0.0.0:5000/docs")
    print(f"\n💡 Manage keys: python src/api_admin.py")
    print("\n" + "=" * 70 + "\n")
    
    uvicorn.run(app, host="0.0.0.0", port=5000)
