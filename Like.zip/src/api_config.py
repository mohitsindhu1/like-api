"""
API Configuration and Key Management
Stores API key securely in environment variable
"""

import os
import sys

# API settings
API_HOST = "0.0.0.0"
API_PORT = 5000
MAX_LIKES_PER_REQUEST = 101  # Maximum likes to send in one request

# Admin password for API key management endpoints
# CRITICAL: MUST be set via environment variable!
ADMIN_PASSWORD = os.getenv("FF_ADMIN_PASSWORD")

# Enforce admin password requirement
if not ADMIN_PASSWORD:
    print("=" * 70)
    print("❌ CRITICAL ERROR: Admin password not set!")
    print("=" * 70)
    print("\n🔐 The FF_ADMIN_PASSWORD environment variable is REQUIRED.")
    print("\nTo fix this:")
    print("  1. Set environment variable:")
    print("     export FF_ADMIN_PASSWORD='your_secure_password_here'")
    print("\n  2. Or create .env file:")
    print("     echo 'FF_ADMIN_PASSWORD=your_secure_password' > .env")
    print("\n⚠️  Server cannot start without admin password for security reasons.")
    print("=" * 70 + "\n")
    sys.exit(1)
