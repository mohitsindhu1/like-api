"""
Multi-API Key Management System with IP-based Location Locking
Har API key first use pe location se lock ho jati hai
"""

import json
import hashlib
import secrets
from datetime import datetime
from typing import Dict, Optional, Tuple
from pathlib import Path

# API keys storage file
API_KEYS_FILE = "api_keys_storage.json"


class APIKeyManager:
    def __init__(self):
        self.keys_file = Path(API_KEYS_FILE)
        self.api_keys = self._load_keys()
    
    def _load_keys(self) -> Dict:
        """Load API keys from storage file"""
        if self.keys_file.exists():
            with open(self.keys_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_keys(self):
        """Save API keys to storage file"""
        with open(self.keys_file, 'w') as f:
            json.dump(self.api_keys, f, indent=2)
    
    def generate_api_key(self, name: str = "default") -> str:
        """
        Generate a new API key
        
        Args:
            name: Friendly name for the API key
            
        Returns:
            Generated API key string
        """
        # Generate secure random key
        key = f"ff_{secrets.token_urlsafe(32)}"
        
        # Store key info
        self.api_keys[key] = {
            "name": name,
            "created_at": datetime.utcnow().isoformat(),
            "locked_ip": None,
            "locked_user_agent": None,
            "first_used_at": None,
            "last_used_at": None,
            "usage_count": 0,
            "is_active": True
        }
        
        self._save_keys()
        return key
    
    def _get_ip_hash(self, ip: str) -> str:
        """Create hash of IP address for storage"""
        return hashlib.sha256(ip.encode()).hexdigest()[:16]
    
    def validate_key(self, api_key: str, client_ip: str, user_agent: str) -> Tuple[bool, str]:
        """
        Validate API key with IP-based location locking
        
        Args:
            api_key: API key to validate
            client_ip: Client's IP address
            user_agent: Client's user agent
            
        Returns:
            (is_valid, error_message)
        """
        # Check if key exists
        if api_key not in self.api_keys:
            return False, "Invalid API key"
        
        key_data = self.api_keys[api_key]
        
        # Check if key is active
        if not key_data.get("is_active", True):
            return False, "API key is deactivated"
        
        # First time use - lock to this IP and user agent
        if key_data["locked_ip"] is None:
            key_data["locked_ip"] = self._get_ip_hash(client_ip)
            key_data["locked_user_agent"] = user_agent
            key_data["first_used_at"] = datetime.utcnow().isoformat()
            key_data["last_used_at"] = datetime.utcnow().isoformat()
            key_data["usage_count"] = 1
            self._save_keys()
            return True, "API key locked to your location"
        
        # Verify IP matches locked location
        current_ip_hash = self._get_ip_hash(client_ip)
        if key_data["locked_ip"] != current_ip_hash:
            return False, "API key is locked to a different location. Access denied."
        
        # Verify user agent matches (optional, can be removed if too strict)
        if key_data["locked_user_agent"] != user_agent:
            return False, "API key is locked to a different device. Access denied."
        
        # Update usage stats
        key_data["last_used_at"] = datetime.utcnow().isoformat()
        key_data["usage_count"] += 1
        self._save_keys()
        
        return True, "Valid"
    
    def deactivate_key(self, api_key: str) -> bool:
        """Deactivate an API key"""
        if api_key in self.api_keys:
            self.api_keys[api_key]["is_active"] = False
            self._save_keys()
            return True
        return False
    
    def activate_key(self, api_key: str) -> bool:
        """Activate a deactivated API key"""
        if api_key in self.api_keys:
            self.api_keys[api_key]["is_active"] = True
            self._save_keys()
            return True
        return False
    
    def reset_key_lock(self, api_key: str) -> bool:
        """Reset location lock for an API key (for re-locking to new location)"""
        if api_key in self.api_keys:
            self.api_keys[api_key]["locked_ip"] = None
            self.api_keys[api_key]["locked_user_agent"] = None
            self.api_keys[api_key]["first_used_at"] = None
            self._save_keys()
            return True
        return False
    
    def get_key_info(self, api_key: str) -> Optional[Dict]:
        """Get information about an API key (without sensitive data)"""
        if api_key in self.api_keys:
            info = self.api_keys[api_key].copy()
            # Return partial IP hash for verification
            if info["locked_ip"]:
                info["locked_ip_preview"] = info["locked_ip"][:8] + "..."
            return info
        return None
    
    def list_all_keys(self) -> Dict:
        """List all API keys with their info"""
        keys_info = {}
        for key, data in self.api_keys.items():
            # Show only last 8 chars of key for security
            masked_key = f"***{key[-8:]}"
            keys_info[masked_key] = {
                "name": data["name"],
                "created_at": data["created_at"],
                "is_locked": data["locked_ip"] is not None,
                "usage_count": data["usage_count"],
                "is_active": data["is_active"],
                "last_used": data.get("last_used_at", "Never")
            }
        return keys_info
    
    def delete_key(self, api_key: str) -> bool:
        """Permanently delete an API key"""
        if api_key in self.api_keys:
            del self.api_keys[api_key]
            self._save_keys()
            return True
        return False


# Global instance
key_manager = APIKeyManager()


if __name__ == "__main__":
    # Test the key manager
    print("=" * 70)
    print("        🔑 API Key Manager Test")
    print("=" * 70)
    
    # Generate a test key
    test_key = key_manager.generate_api_key("Test Key 1")
    print(f"\n✅ Generated API Key: {test_key}")
    
    # Test validation
    is_valid, msg = key_manager.validate_key(test_key, "192.168.1.1", "Mozilla/5.0")
    print(f"\n🔍 First use validation: {is_valid} - {msg}")
    
    # Test from same IP
    is_valid, msg = key_manager.validate_key(test_key, "192.168.1.1", "Mozilla/5.0")
    print(f"🔍 Same IP validation: {is_valid} - {msg}")
    
    # Test from different IP
    is_valid, msg = key_manager.validate_key(test_key, "192.168.1.2", "Mozilla/5.0")
    print(f"🔍 Different IP validation: {is_valid} - {msg}")
    
    # Show key info
    info = key_manager.get_key_info(test_key)
    print(f"\n📊 Key Info:")
    print(json.dumps(info, indent=2))
    
    # List all keys
    print(f"\n📋 All Keys:")
    print(json.dumps(key_manager.list_all_keys(), indent=2))
