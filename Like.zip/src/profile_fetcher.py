"""
Profile Fetcher Module
Fetches user profile information (name and like count) from Free Fire API
"""

import asyncio
import json
from typing import Dict, Any

from count_likes import GetAccountInformation


async def get_profile_info(target_uid: int, region: str = "") -> Dict[str, Any]:
    """
    Fetch profile information for a target UID using the same method as /info endpoint
    
    Args:
        target_uid: Target user ID
        region: Server region (IND, BD, BR, US, etc.) - leave empty for auto-detection
        
    Returns:
        Dictionary with profile info: {
            'uid': int,
            'nickname': str,
            'likes': int,
            'success': bool,
            'error': str (if failed),
            'detected_region': str (if auto-detected)
        }
    """
    try:
        if region:
            region = region.upper()
        
        result = await GetAccountInformation(target_uid, "0", region, "/GetPlayerPersonalShow")
        
        if isinstance(result, dict) and result.get("error"):
            return {
                'success': False,
                'error': result.get("message", "Unknown error"),
                'uid': target_uid,
                'nickname': f"Player_{target_uid}",
                'likes': 0
            }
        elif isinstance(result, dict) and "basicInfo" in result:
            basic_info = result["basicInfo"]
            
            if isinstance(basic_info, dict):
                player_nickname = basic_info.get("nickname", f"Player_{target_uid}")
                likes = basic_info.get("liked", 0)
                level = basic_info.get("level", 0)
                
                profile_data = {
                    'success': True,
                    'uid': target_uid,
                    'nickname': player_nickname,
                    'likes': likes,
                    'level': level
                }
                
                if result.get("detected_region"):
                    profile_data['detected_region'] = result.get("detected_region")
                
                return profile_data
            else:
                return {
                    'success': True,
                    'uid': target_uid,
                    'nickname': f"Player_{target_uid}",
                    'likes': 0
                }
        else:
            return {
                'success': True,
                'uid': target_uid,
                'nickname': f"Player_{target_uid}",
                'likes': 0,
                'note': 'Profile data not available'
            }
                
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'uid': target_uid,
            'nickname': f"Player_{target_uid}",
            'likes': 0
        }


if __name__ == "__main__":
    # Test the profile fetcher
    async def test():
        profile = await get_profile_info(111119900, "IND")
        print("Profile Info:", json.dumps(profile, indent=2))
    
    asyncio.run(test())
